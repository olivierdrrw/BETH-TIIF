<audio

 controls

 src={audioUrl}

/>