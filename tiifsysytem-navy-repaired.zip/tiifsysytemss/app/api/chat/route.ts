import OpenAI from "openai";

const openai =
 new OpenAI({

  apiKey:
  process.env.OPENAI_API_KEY,

 });

export async function POST(
 req:Request
){

 const body =
 await req.json();

 const stream =
 await openai.responses.create({

  model:"gpt-5",

  input:body.prompt,

  stream:true,

 });

 const encoder = new TextEncoder();

 const readable = new ReadableStream({
  async start(controller) {
   try {
    for await (const event of stream) {
     if (event.type === "response.output_text.delta" && "delta" in event) {
      controller.enqueue(encoder.encode(event.delta as string));
     }
    }
   } catch (error) {
    controller.error(error);
    return;
   }
   controller.close();
  },
 });

 return new Response(readable, {
  headers: { "Content-Type": "text/plain; charset=utf-8" },
 });

}