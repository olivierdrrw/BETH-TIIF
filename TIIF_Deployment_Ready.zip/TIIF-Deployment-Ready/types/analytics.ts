export interface DashboardAnalytics {
  totalUsers: number;

  activeUsers: number;

  aiSessions: number;

  riskAlerts: number;

  averageWellnessScore: number;
}